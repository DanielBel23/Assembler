/*creator header file. creator unites all the parts of the assembler*/
int assemble(char*);/*recieves a name of file and assembles it*/
